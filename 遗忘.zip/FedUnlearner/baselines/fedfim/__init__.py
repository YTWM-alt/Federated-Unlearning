# baselines/fedfim/__init__.py
from .fedfim import run_fedfIM
