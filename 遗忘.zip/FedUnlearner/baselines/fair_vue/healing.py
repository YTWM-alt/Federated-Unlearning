import torch
from typing import Dict

def selective_kd_heal(student: torch.nn.Module,
                      teacher: torch.nn.Module,
                      dataloader,
                      v_spec: torch.Tensor,
                      num_steps: int = 200,
                      lr: float = 1e-4,
                      T: float = 2.0,
                      lambda_kd: float = 0.5,
                      lambda_ortho: float = 1e-3,
                      device: str = "cpu"):
    """
    选择性知识蒸馏治疗：恢复通用能力，抑制特异方向。
    """
    student.train()
    teacher.eval()
    opt = torch.optim.AdamW(student.parameters(), lr=lr)
    ce = torch.nn.CrossEntropyLoss()

    for step, (x, y) in enumerate(dataloader):
        if step >= num_steps:
            break
        x, y = x.to(device), y.to(device)
        student.zero_grad(set_to_none=True)
        with torch.no_grad():
            tlogits = teacher(x)
        slogits = student(x)
        loss_task = ce(slogits, y)
        ps = torch.log_softmax(slogits / T, dim=-1)
        pt = torch.softmax(tlogits / T, dim=-1)
        loss_kd = torch.nn.functional.kl_div(ps, pt, reduction="batchmean") * (T ** 2)
        loss = loss_task + lambda_kd * loss_kd
        # 防止回流：正交方向惩罚
        if v_spec is not None and v_spec.numel() > 0:
            with torch.no_grad():
                vec = torch.cat([p.detach().view(-1) for p in student.parameters() if p.requires_grad])
                Q, _ = torch.linalg.qr(v_spec, mode='reduced')
                proj = Q @ (Q.T @ vec)
            loss = loss + lambda_ortho * torch.sum(proj ** 2)
        loss.backward()
        opt.step()
